import { Pipe2Pipe } from './pipe2.pipe';

describe('Pipe2Pipe', () => {
  it('create an instance', () => {
    const pipe = new Pipe2Pipe();
    expect(pipe).toBeTruthy();
  });
});
